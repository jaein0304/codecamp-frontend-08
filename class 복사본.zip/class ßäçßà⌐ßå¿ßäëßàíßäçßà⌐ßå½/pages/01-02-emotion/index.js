import { Wrapper, EmailInput } from '../../styles/emotion'
export default function EmotionPage() {
    // JavaScript 쓰는 곳 

    return (
        //HTML 쓰는 곳 
        <Wrapper>
            안녕하세요! 
            <EmailInput type="text"/>
            <EmailInput type="text"/>
            <img src="/vercel.svg"/>
            </Wrapper>
    )
}