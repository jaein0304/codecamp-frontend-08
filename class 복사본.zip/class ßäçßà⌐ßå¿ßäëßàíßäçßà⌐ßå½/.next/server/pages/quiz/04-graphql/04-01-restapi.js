"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz/04-graphql/04-01-restapi";
exports.ids = ["pages/quiz/04-graphql/04-01-restapi"];
exports.modules = {

/***/ "./pages/quiz/04-graphql/04-01-restapi.js":
/*!************************************************!*\
  !*** ./pages/quiz/04-graphql/04-01-restapi.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RestApiPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction RestApiPage() {\n    const onClickRestApi = ()=>{\n        const result = axios__WEBPACK_IMPORTED_MODULE_2___default().get(\"https://koreanjson.com/users\");\n        console.log(result);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickRestApi,\n            children: \"REST-API 요청하기\"\n        }, void 0, false, {\n            fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/quiz/04-graphql/04-01-restapi.js\",\n            lineNumber: 13,\n            columnNumber: 9\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6LzA0LWdyYXBocWwvMDQtMDEtcmVzdGFwaS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFnQztBQUNQO0FBRVYsUUFBUSxDQUFDRSxXQUFXLEdBQUcsQ0FBQztJQUVuQyxLQUFLLENBQUNDLGNBQWMsT0FBUyxDQUFDO1FBQzFCLEtBQUssQ0FBQ0MsTUFBTSxHQUFHSCxnREFBUyxDQUFDLENBQThCO1FBQ3ZESyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsTUFBTTtJQUN0QixDQUFDO0lBRUQsTUFBTTs4RkFFREksQ0FBTTtZQUFDQyxPQUFPLEVBQUVOLGNBQWM7c0JBQUUsQ0FBYTs7Ozs7OztBQUd0RCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9xdWl6LzA0LWdyYXBocWwvMDQtMDEtcmVzdGFwaS5qcz84YmNmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXN0QXBpUGFnZSgpIHtcblxuICAgIGNvbnN0IG9uQ2xpY2tSZXN0QXBpID0gKCkgPT4ge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBheGlvcy5nZXQoXCJodHRwczovL2tvcmVhbmpzb24uY29tL3VzZXJzXCIpO1xuICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQpXG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrUmVzdEFwaX0+UkVTVC1BUEkg7JqU7LKt7ZWY6riwPC9idXR0b24+XG4gICAgICAgIDwvPlxuICAgIClcbn0iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJheGlvcyIsIlJlc3RBcGlQYWdlIiwib25DbGlja1Jlc3RBcGkiLCJyZXN1bHQiLCJnZXQiLCJjb25zb2xlIiwibG9nIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/quiz/04-graphql/04-01-restapi.js\n");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz/04-graphql/04-01-restapi.js"));
module.exports = __webpack_exports__;

})();