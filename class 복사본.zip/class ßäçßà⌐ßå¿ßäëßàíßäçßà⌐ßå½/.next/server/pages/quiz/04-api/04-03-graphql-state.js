"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz/04-api/04-03-graphql-state";
exports.ids = ["pages/quiz/04-api/04-03-graphql-state"];
exports.modules = {

/***/ "./pages/quiz/04-api/04-03-graphql-state.js":
/*!**************************************************!*\
  !*** ./pages/quiz/04-api/04-03-graphql-state.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ GrapghqlPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst CREATE_BOARD = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\nmutation createBoard($writer: String, $title: String, $contents: String) {\n    createBoard(writer: $writer, title: $title, contents : $contents) {\n        _id,\n        number,\n        message\n    }\n}`;\nfunction GrapghqlPage() {\n    const { 0: writer , 1: setWriter  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const { 0: title , 1: setTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const { 0: contents , 1: setContents  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const [createBoard] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(CREATE_BOARD);\n    const onClickGraphqlApi = async ()=>{\n        const result = await createBoard({\n            variables: {\n                writer: writer,\n                title: title,\n                contents: contents\n            }\n        });\n        console.log(result);\n        console.log(result.data.createBoard.message);\n    };\n    const onChangeWriter = (event)=>{\n        setWriter(event.target.value);\n    };\n    const onChangeTitle = (event)=>{\n        setTitle(event.target.value);\n    };\n    const onChangeContents = (event)=>{\n        setContents(event.target.value);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickGraphqlApi,\n            children: \"GRAPHQL-API 요청하기\"\n        }, void 0, false, {\n            fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/quiz/04-api/04-03-graphql-state.js\",\n            lineNumber: 45,\n            columnNumber: 13\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6LzA0LWFwaS8wNC0wMy1ncmFwaHFsLXN0YXRlLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQWlEO0FBQ2pCO0FBRWhDLEtBQUssQ0FBQ0csWUFBWSxHQUFHRiwrQ0FBRyxDQUFDOzs7Ozs7O0NBT3hCO0FBRWMsUUFBUSxDQUFDRyxZQUFZLEdBQUcsQ0FBQztJQUNwQyxLQUFLLE1BQUVDLE1BQU0sTUFBRUMsU0FBUyxNQUFJSiwrQ0FBUSxDQUFDLENBQUU7SUFDdkMsS0FBSyxNQUFFSyxLQUFLLE1BQUVDLFFBQVEsTUFBSU4sK0NBQVEsQ0FBQyxDQUFFO0lBQ3JDLEtBQUssTUFBRU8sUUFBUSxNQUFFQyxXQUFXLE1BQUlSLCtDQUFRLENBQUMsQ0FBRTtJQUMzQyxLQUFLLEVBQUVTLFdBQVcsSUFBSVgsMkRBQVcsQ0FBQ0csWUFBWTtJQUU5QyxLQUFLLENBQUNTLGlCQUFpQixhQUFlLENBQUM7UUFDbkMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDRixXQUFXLENBQUMsQ0FBQztZQUM5QkcsU0FBUyxFQUFFLENBQUM7Z0JBQ1JULE1BQU0sRUFBRUEsTUFBTTtnQkFDZEUsS0FBSyxFQUFFQSxLQUFLO2dCQUNaRSxRQUFRLEVBQUVBLFFBQVE7WUFDdEIsQ0FBQztRQUNMLENBQUM7UUFDRE0sT0FBTyxDQUFDQyxHQUFHLENBQUNILE1BQU07UUFDbEJFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxNQUFNLENBQUNJLElBQUksQ0FBQ04sV0FBVyxDQUFDTyxPQUFPO0lBQy9DLENBQUM7SUFFRCxLQUFLLENBQUNDLGNBQWMsSUFBSUMsS0FBSyxHQUFLLENBQUM7UUFDL0JkLFNBQVMsQ0FBQ2MsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDaEMsQ0FBQztJQUVELEtBQUssQ0FBQ0MsYUFBYSxJQUFJSCxLQUFLLEdBQUssQ0FBQztRQUM5QlosUUFBUSxDQUFDWSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUMvQixDQUFDO0lBRUQsS0FBSyxDQUFDRSxnQkFBZ0IsSUFBSUosS0FBSyxHQUFLLENBQUM7UUFDakNWLFdBQVcsQ0FBQ1UsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDbEMsQ0FBQztJQUVELE1BQU07OEZBRUdHLENBQU07WUFBQ0MsT0FBTyxFQUFFZCxpQkFBaUI7c0JBQUUsQ0FBZ0I7Ozs7Ozs7QUFHaEUsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvcXVpei8wNC1hcGkvMDQtMDMtZ3JhcGhxbC1zdGF0ZS5qcz85ODYzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uLCBncWwgfSBmcm9tICdAYXBvbGxvL2NsaWVudCdcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IENSRUFURV9CT0FSRCA9IGdxbGBcbm11dGF0aW9uIGNyZWF0ZUJvYXJkKCR3cml0ZXI6IFN0cmluZywgJHRpdGxlOiBTdHJpbmcsICRjb250ZW50czogU3RyaW5nKSB7XG4gICAgY3JlYXRlQm9hcmQod3JpdGVyOiAkd3JpdGVyLCB0aXRsZTogJHRpdGxlLCBjb250ZW50cyA6ICRjb250ZW50cykge1xuICAgICAgICBfaWQsXG4gICAgICAgIG51bWJlcixcbiAgICAgICAgbWVzc2FnZVxuICAgIH1cbn1gXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyYXBnaHFsUGFnZSgpIHtcbiAgICBjb25zdCBbd3JpdGVyLCBzZXRXcml0ZXJdID0gdXNlU3RhdGUoXCJcIilcbiAgICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKFwiXCIpXG4gICAgY29uc3QgW2NvbnRlbnRzLCBzZXRDb250ZW50c10gPSB1c2VTdGF0ZShcIlwiKVxuICAgIGNvbnN0IFtjcmVhdGVCb2FyZF0gPSB1c2VNdXRhdGlvbihDUkVBVEVfQk9BUkQpXG5cbiAgICBjb25zdCBvbkNsaWNrR3JhcGhxbEFwaSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY3JlYXRlQm9hcmQoe1xuICAgICAgICAgICAgdmFyaWFibGVzOiB7XG4gICAgICAgICAgICAgICAgd3JpdGVyOiB3cml0ZXIsXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgICAgICAgICAgIGNvbnRlbnRzOiBjb250ZW50c1xuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQpXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhLmNyZWF0ZUJvYXJkLm1lc3NhZ2UpXG4gICAgfVxuXG4gICAgY29uc3Qgb25DaGFuZ2VXcml0ZXIgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgc2V0V3JpdGVyKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgICB9XG5cbiAgICBjb25zdCBvbkNoYW5nZVRpdGxlID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIHNldFRpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgICB9XG5cbiAgICBjb25zdCBvbkNoYW5nZUNvbnRlbnRzID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIHNldENvbnRlbnRzKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrR3JhcGhxbEFwaX0+R1JBUEhRTC1BUEkg7JqU7LKt7ZWY6riwPC9idXR0b24+XG4gICAgICAgIDwvPlxuICAgIClcbn0iXSwibmFtZXMiOlsidXNlTXV0YXRpb24iLCJncWwiLCJ1c2VTdGF0ZSIsIkNSRUFURV9CT0FSRCIsIkdyYXBnaHFsUGFnZSIsIndyaXRlciIsInNldFdyaXRlciIsInRpdGxlIiwic2V0VGl0bGUiLCJjb250ZW50cyIsInNldENvbnRlbnRzIiwiY3JlYXRlQm9hcmQiLCJvbkNsaWNrR3JhcGhxbEFwaSIsInJlc3VsdCIsInZhcmlhYmxlcyIsImNvbnNvbGUiLCJsb2ciLCJkYXRhIiwibWVzc2FnZSIsIm9uQ2hhbmdlV3JpdGVyIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ2hhbmdlVGl0bGUiLCJvbkNoYW5nZUNvbnRlbnRzIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/quiz/04-api/04-03-graphql-state.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz/04-api/04-03-graphql-state.js"));
module.exports = __webpack_exports__;

})();