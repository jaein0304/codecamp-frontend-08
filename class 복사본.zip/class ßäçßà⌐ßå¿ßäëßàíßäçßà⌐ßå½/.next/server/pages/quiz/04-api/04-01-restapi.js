"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz/04-api/04-01-restapi";
exports.ids = ["pages/quiz/04-api/04-01-restapi"];
exports.modules = {

/***/ "./pages/quiz/04-api/04-01-restapi.js":
/*!********************************************!*\
  !*** ./pages/quiz/04-api/04-01-restapi.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RestApiPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction RestApiPage() {\n    const onClickRestApi = async ()=>{\n        const result = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(\"https://koreanjson.com/users\");\n        console.log(result);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickRestApi,\n            children: \"REST-API 요청하기\"\n        }, void 0, false, {\n            fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/quiz/04-api/04-01-restapi.js\",\n            lineNumber: 13,\n            columnNumber: 9\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6LzA0LWFwaS8wNC0wMS1yZXN0YXBpLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQWdDO0FBQ1A7QUFFVixRQUFRLENBQUNFLFdBQVcsR0FBRyxDQUFDO0lBRW5DLEtBQUssQ0FBQ0MsY0FBYyxhQUFjLENBQUM7UUFDL0IsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDSCxnREFBUyxDQUFDLENBQThCO1FBQzdESyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsTUFBTTtJQUN0QixDQUFDO0lBRUQsTUFBTTs4RkFFREksQ0FBTTtZQUFDQyxPQUFPLEVBQUVOLGNBQWM7c0JBQUUsQ0FBYTs7Ozs7OztBQUd0RCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9xdWl6LzA0LWFwaS8wNC0wMS1yZXN0YXBpLmpzPzBlZjkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlc3RBcGlQYWdlKCkge1xuXG4gICAgY29uc3Qgb25DbGlja1Jlc3RBcGkgPSBhc3luYygpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYXhpb3MuZ2V0KFwiaHR0cHM6Ly9rb3JlYW5qc29uLmNvbS91c2Vyc1wiKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzdWx0KVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja1Jlc3RBcGl9PlJFU1QtQVBJIOyalOyyre2VmOq4sDwvYnV0dG9uPlxuICAgICAgICA8Lz5cbiAgICApXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwiYXhpb3MiLCJSZXN0QXBpUGFnZSIsIm9uQ2xpY2tSZXN0QXBpIiwicmVzdWx0IiwiZ2V0IiwiY29uc29sZSIsImxvZyIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/quiz/04-api/04-01-restapi.js\n");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz/04-api/04-01-restapi.js"));
module.exports = __webpack_exports__;

})();