"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz/04-api/04-02-graphql";
exports.ids = ["pages/quiz/04-api/04-02-graphql"];
exports.modules = {

/***/ "./pages/quiz/04-api/04-02-graphql.js":
/*!********************************************!*\
  !*** ./pages/quiz/04-api/04-02-graphql.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ GrapghqlPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst CREATE_BOARD = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\nmutation{\n    createBoard(writer:\"정재인\", title:\"1번\", contents:\"하드코딩\"){\n        _id\n        number\n        message\n    }\n}\n`;\nfunction GrapghqlPage() {\n    const [createBoard] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(CREATE_BOARD);\n    const onClickGraphqlApi = async ()=>{\n        const result = await createBoard();\n        console.log(result);\n        console.log(result.data.createBoard.message);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: onClickGraphqlApi,\n            children: \"GRAPHQL-API 요청하기\"\n        }, void 0, false, {\n            fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/quiz/04-api/04-02-graphql.js\",\n            lineNumber: 25,\n            columnNumber: 13\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6LzA0LWFwaS8wNC0wMi1ncmFwaHFsLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQWlEO0FBQ2pCO0FBRWhDLEtBQUssQ0FBQ0csWUFBWSxHQUFHRiwrQ0FBRyxDQUFDOzs7Ozs7OztBQVF6QjtBQUVlLFFBQVEsQ0FBQ0csWUFBWSxHQUFHLENBQUM7SUFDcEMsS0FBSyxFQUFFQyxXQUFXLElBQUlMLDJEQUFXLENBQUNHLFlBQVk7SUFFOUMsS0FBSyxDQUFDRyxpQkFBaUIsYUFBZSxDQUFDO1FBQ25DLEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEtBQUssQ0FBQ0YsV0FBVztRQUNoQ0csT0FBTyxDQUFDQyxHQUFHLENBQUNGLE1BQU07UUFDbEJDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRixNQUFNLENBQUNHLElBQUksQ0FBQ0wsV0FBVyxDQUFDTSxPQUFPO0lBQy9DLENBQUM7SUFFRCxNQUFNOzhGQUVHQyxDQUFNO1lBQUNDLE9BQU8sRUFBRVAsaUJBQWlCO3NCQUFFLENBQWdCOzs7Ozs7O0FBR2hFLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3F1aXovMDQtYXBpLzA0LTAyLWdyYXBocWwuanM/ZWJjZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiwgZ3FsIH0gZnJvbSAnQGFwb2xsby9jbGllbnQnXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBDUkVBVEVfQk9BUkQgPSBncWxgXG5tdXRhdGlvbntcbiAgICBjcmVhdGVCb2FyZCh3cml0ZXI6XCLsoJXsnqzsnbhcIiwgdGl0bGU6XCIx67KIXCIsIGNvbnRlbnRzOlwi7ZWY65Oc7L2U65SpXCIpe1xuICAgICAgICBfaWRcbiAgICAgICAgbnVtYmVyXG4gICAgICAgIG1lc3NhZ2VcbiAgICB9XG59XG5gXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyYXBnaHFsUGFnZSgpIHtcbiAgICBjb25zdCBbY3JlYXRlQm9hcmRdID0gdXNlTXV0YXRpb24oQ1JFQVRFX0JPQVJEKVxuXG4gICAgY29uc3Qgb25DbGlja0dyYXBocWxBcGkgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNyZWF0ZUJvYXJkKCkgXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdClcbiAgICAgICAgY29uc29sZS5sb2cocmVzdWx0LmRhdGEuY3JlYXRlQm9hcmQubWVzc2FnZSlcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrR3JhcGhxbEFwaX0+R1JBUEhRTC1BUEkg7JqU7LKt7ZWY6riwPC9idXR0b24+XG4gICAgICAgIDwvPlxuICAgIClcbn0iXSwibmFtZXMiOlsidXNlTXV0YXRpb24iLCJncWwiLCJ1c2VTdGF0ZSIsIkNSRUFURV9CT0FSRCIsIkdyYXBnaHFsUGFnZSIsImNyZWF0ZUJvYXJkIiwib25DbGlja0dyYXBocWxBcGkiLCJyZXN1bHQiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsIm1lc3NhZ2UiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/quiz/04-api/04-02-graphql.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz/04-api/04-02-graphql.js"));
module.exports = __webpack_exports__;

})();