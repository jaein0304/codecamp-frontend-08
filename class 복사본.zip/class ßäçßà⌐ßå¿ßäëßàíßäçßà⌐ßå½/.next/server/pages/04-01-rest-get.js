"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/04-01-rest-get";
exports.ids = ["pages/04-01-rest-get"];
exports.modules = {

/***/ "./pages/04-01-rest-get/index.js":
/*!***************************************!*\
  !*** ./pages/04-01-rest-get/index.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RestGetPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction RestGetPage() {\n    const { 0: title , 1: setTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();\n    const onClickRestApiAsync = ()=>{\n        const result = axios__WEBPACK_IMPORTED_MODULE_1___default().get(\"https://koreanjson.com/posts/1\"); //조회\n        console.log(result);\n    };\n    const onClickRestApiSync = async ()=>{\n        const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(\"https://koreanjson.com/posts/1\"); //조회\n        console.log(result);\n        console.log(result.data.title);\n        //document.getElementById(\"qqq\").innerText = result.data.title\n        setTitle(result.data.title);\n    };\n    /*function onClickRestApiAsync() {\n    const result = axios.get(\"https://koreanjson.com/posts/1\"); //조회\n    console.log(result);\n  }\n\n  async function onClickRestApiSync() {\n    const result = axios.get(\"https://koreanjson.com/posts/1\"); //조회\n    console.log(result);\n    console.log(result.data.title)\n    //document.getElementById(\"qqq\").innerText = result.data.title\n    setTitle(result.data.title)\n  } */ return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickRestApiAsync,\n                children: \"REST-API 비동기 요청\"\n            }, void 0, false, {\n                fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/04-01-rest-get/index.js\",\n                lineNumber: 36,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickRestApiSync,\n                children: \"REST-API 동기 요청\"\n            }, void 0, false, {\n                fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/04-01-rest-get/index.js\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: title\n            }, void 0, false, {\n                fileName: \"/Users/jaein/Desktop/codecamp-frontend-08-Jaein/class/pages/04-01-rest-get/index.js\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wNC0wMS1yZXN0LWdldC9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUF5QjtBQUNPO0FBRWpCLFFBQVEsQ0FBQ0UsV0FBVyxHQUFHLENBQUM7SUFFckMsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVE7SUFFbEMsS0FBSyxDQUFDSSxtQkFBbUIsT0FBUyxDQUFDO1FBQ2pDLEtBQUssQ0FBQ0MsTUFBTSxHQUFHTixnREFBUyxDQUFDLENBQWdDLGlDQUFHLENBQUksRUFBSTtRQUNoRVEsT0FBRyxDQUFDQyxHQUFHLENBQUNILE1BQU07SUFDcEIsQ0FBQztJQUVELEtBQUssQ0FBQ0ksa0JBQWtCLGFBQWEsQ0FBQztRQUNwQyxLQUFLLENBQUNKLE1BQU0sR0FBRyxLQUFLLENBQUNOLGdEQUFTLENBQUMsQ0FBZ0MsaUNBQUcsQ0FBSSxFQUFJO1FBQ3RFUSxPQUFHLENBQUNDLEdBQUcsQ0FBQ0gsTUFBTTtRQUNsQkUsT0FBTyxDQUFDQyxHQUFHLENBQUNILE1BQU0sQ0FBQ0ssSUFBSSxDQUFDUixLQUFLO1FBQzdCLEVBQThEO1FBQzlEQyxRQUFRLENBQUNFLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDUixLQUFLO0lBQzVCLENBQUM7SUFFRCxFQVdJOzs7Ozs7Ozs7OztJQUFBLEdBRUosTUFBTTs7d0ZBRURTLENBQU07Z0JBQUNDLE9BQU8sRUFBRVIsbUJBQW1COzBCQUFFLENBQWU7Ozs7Ozt3RkFDMUNPLENBQUo7Z0JBQUNDLE9BQU8sRUFBRUgsa0JBQWtCOzBCQUFFLENBQWM7Ozs7Ozt3RkFFbERJLENBQUc7MEJBQUVYLEtBQUs7Ozs7Ozs7O0FBR2pCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzA0LTAxLXJlc3QtZ2V0L2luZGV4LmpzP2M1NmQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlc3RHZXRQYWdlKCkge1xuXG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoKVxuXG4gIGNvbnN0IG9uQ2xpY2tSZXN0QXBpQXN5bmMgPSAoKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXhpb3MuZ2V0KFwiaHR0cHM6Ly9rb3JlYW5qc29uLmNvbS9wb3N0cy8xXCIpOyAvL+yhsO2ajFxuICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gIH1cblxuICBjb25zdCBvbkNsaWNrUmVzdEFwaVN5bmMgPSBhc3luYygpID0+e1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF4aW9zLmdldChcImh0dHBzOi8va29yZWFuanNvbi5jb20vcG9zdHMvMVwiKTsgLy/sobDtmoxcbiAgICBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhLnRpdGxlKVxuICAgIC8vZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJxcXFcIikuaW5uZXJUZXh0ID0gcmVzdWx0LmRhdGEudGl0bGVcbiAgICBzZXRUaXRsZShyZXN1bHQuZGF0YS50aXRsZSlcbiAgfVxuXG4gIC8qZnVuY3Rpb24gb25DbGlja1Jlc3RBcGlBc3luYygpIHtcbiAgICBjb25zdCByZXN1bHQgPSBheGlvcy5nZXQoXCJodHRwczovL2tvcmVhbmpzb24uY29tL3Bvc3RzLzFcIik7IC8v7KGw7ZqMXG4gICAgY29uc29sZS5sb2cocmVzdWx0KTtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIG9uQ2xpY2tSZXN0QXBpU3luYygpIHtcbiAgICBjb25zdCByZXN1bHQgPSBheGlvcy5nZXQoXCJodHRwczovL2tvcmVhbmpzb24uY29tL3Bvc3RzLzFcIik7IC8v7KGw7ZqMXG4gICAgY29uc29sZS5sb2cocmVzdWx0KTtcbiAgICBjb25zb2xlLmxvZyhyZXN1bHQuZGF0YS50aXRsZSlcbiAgICAvL2RvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicXFxXCIpLmlubmVyVGV4dCA9IHJlc3VsdC5kYXRhLnRpdGxlXG4gICAgc2V0VGl0bGUocmVzdWx0LmRhdGEudGl0bGUpXG4gIH0gKi9cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tSZXN0QXBpQXN5bmN9PlJFU1QtQVBJIOu5hOuPmeq4sCDsmpTssq08L2J1dHRvbj5cbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja1Jlc3RBcGlTeW5jfT5SRVNULUFQSSDrj5nquLAg7JqU7LKtPC9idXR0b24+XG4gICAgICB7LyogPGRpdiBpZD1cInFxcVwiPjwvZGl2PiAqL30gXG4gICAgICA8ZGl2Pnt0aXRsZX08L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJheGlvcyIsInVzZVN0YXRlIiwiUmVzdEdldFBhZ2UiLCJ0aXRsZSIsInNldFRpdGxlIiwib25DbGlja1Jlc3RBcGlBc3luYyIsInJlc3VsdCIsImdldCIsImNvbnNvbGUiLCJsb2ciLCJvbkNsaWNrUmVzdEFwaVN5bmMiLCJkYXRhIiwiYnV0dG9uIiwib25DbGljayIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/04-01-rest-get/index.js\n");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/04-01-rest-get/index.js"));
module.exports = __webpack_exports__;

})();