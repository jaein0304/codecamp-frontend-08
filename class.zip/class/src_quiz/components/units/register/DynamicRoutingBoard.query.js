import { gql } from '@apollo/client'

//흔히 대문자로 사용함
export const CREATE_BOARD = gql`
mutation createBoard($writer: String, $title: String, $contents: String) { 
    createBoard(writer: $writer, title: $title, contents: $contents) {
        _id
        number
        message
    }
}
`
