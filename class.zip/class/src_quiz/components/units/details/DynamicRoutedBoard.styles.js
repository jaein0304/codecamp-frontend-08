import styled from '@emotion/styled'

export const RedInput = styled.input`
    border-color: red;
`

export const RedButton = styled.input`
    border-color: red;
`

// export default function QQQ() {
// }