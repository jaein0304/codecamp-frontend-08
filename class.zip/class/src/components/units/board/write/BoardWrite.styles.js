import styled from '@emotion/styled'

export const RedInput = styled.input`
    border-color: red;
`

export const RedButton = styled.button`
    border-color: red;

`

// export default function QQQ() {
// }