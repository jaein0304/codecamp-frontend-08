export default function Mypage() {
    // JavaScript 쓰는 곳 

    return (
        //HTML 쓰는 곳 
        <div>
            안녕하세요! 
            <input type="text"/>
            </div>
    )
}