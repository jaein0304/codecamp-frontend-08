// import DynamicRoutedBoard from "../../../../src_quiz/components/units/router/DynamicRoutedBoard.container"
import DynamicRoutedBoard from "../../../../src_quiz/components/units/details/DynamicRoutedBoard.container"

export default function StaticRoutedPage(){

    return (
        <>
            <DynamicRoutedBoard/>
            {/* <div>{router.query.number}번 게시글 이동이 완료되었습니다.</div> */}
        </>
    )
}