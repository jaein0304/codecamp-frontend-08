// const classmates = [
//     { name: "철수", age: 10, school: "토끼초등학교" },
//     { name: "영희", age: 13, school: "다람쥐초등학교" },
//     { name: "훈이", age: 11, school: "토끼초등학교" }
// ]

// //토끼초등학교 골라내기
// classmates.filter((school) => "토끼초등학교");
// classmates.map((candy) => ({ candy: "candy : 10" }));