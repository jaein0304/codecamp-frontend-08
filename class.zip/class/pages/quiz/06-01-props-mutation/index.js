// import DynamicRouting from '../../../src_quiz/components/units/router/DynamicRoutingBoard.container'
import DynamicRouting from "../../../src_quiz/components/units/register/DynamicRoutingBoard.container"

export default function GraphqlMutationPage() {
    

    return <DynamicRouting />
}
