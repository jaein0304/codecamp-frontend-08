export default function StaticRoutedBoardPage() {
    
    return  <div>2번 게시글 이동이 완료되었습니다</div>
    

}